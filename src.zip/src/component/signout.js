import React from "react";

function signout() {
  return <div>signout</div>;
}

export default signout;
